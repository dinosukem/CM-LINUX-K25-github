#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void handler(int sig) {
    printf("Received signal %d!\n", sig);
}

int main() {
    sigset_t set;
    
    // Register handler
    signal(SIGINT, handler);
    
    printf("=== PROGRAM START ===\n\n");
    
    // 1. BLOCK SIGNAL
    sigemptyset(&set);           // Create empty set
    sigaddset(&set, SIGINT);     // Add SIGINT to set
    sigprocmask(SIG_BLOCK, &set, NULL);  // BLOCK SIGINT, waiting in queue
    
    printf("SIGINT is BLOCKED (Ctrl+C won't work)\n");
    printf("Try pressing Ctrl+C for 5 seconds...\n");
    sleep(10);
    
    // 2. UNBLOCK SIGNAL
    sigprocmask(SIG_UNBLOCK, &set, NULL);  // UNBLOCK SIGINT, Immediately delivers any pending signals
    
    printf("SIGINT is UNBLOCKED (Ctrl+C works again)\n");
    printf("Try pressing Ctrl+C for 5 seconds...\n");
    sleep(100);
    
    printf("=== END ===\n");
    return 0;
}
