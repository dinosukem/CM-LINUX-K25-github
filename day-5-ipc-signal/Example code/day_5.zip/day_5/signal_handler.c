#include <stdio.h>
#include <signal.h>
#include <unistd.h>

// Signal handler function
void handle_sigint(int signo) {
    // Stage 5: Handler executes
    printf("\n[SIGNAL] Caught SIGKILL (signal %d)\n", signo);
    // Stage 6: Return immediately
}

int main() {
    // Register signal handler (Stage 1 & 2)
    signal(SIGKILL, handle_sigint);
    
    // Stage 3
    printf("Program running... Press Ctrl+C to test\n");
    printf("PID: %d\n\n", getpid());
    
    while (1) {
        printf("Working...\n");
        sleep(2);
        // Stage 7: Program execution continues
    }
    
    return 0;
}
