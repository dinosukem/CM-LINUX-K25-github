#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

void child_handler(int signo) {
    printf("[CHILD] Received signal %d from parent\n", signo);
}

int main() {
    pid_t pid = fork();
    
    if (pid == 0) {
        // ===== CHILD PROCESS =====
        signal(SIGUSR1, child_handler);
        
        printf("[CHILD] PID=%d, waiting for signal...\n", getpid());
        
        while (1) {
            sleep(1);
        }
        
    } else {
        // ===== PARENT PROCESS =====
        printf("[PARENT] Child PID=%d\n", pid);
        
        sleep(2);
        printf("[PARENT] Sending SIGUSR1 to child...\n");
        kill(pid, SIGUSR1);
        
        sleep(2);
        printf("[PARENT] Sending SIGTERM to child...\n");
        kill(pid, SIGTERM);
        
        wait(NULL);
        printf("[PARENT] Child terminated\n");
    }
    
    return 0;
}
