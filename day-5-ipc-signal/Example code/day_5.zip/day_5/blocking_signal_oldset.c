#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void print_mask(const char *label) {
    sigset_t current;
    sigprocmask(SIG_BLOCK, NULL, &current); // Copy kernel mask to current
    
    printf("%s: ", label);
    if (sigismember(&current, SIGINT)) printf("SIGINT ");
    if (sigismember(&current, SIGTERM)) printf("SIGTERM ");
    printf("\n");
}

void handler(int sig) {
    printf("[Handler] Signal %d\n", sig);
}

// Reusable function - doesn't know caller's state
void critical_section() {
    sigset_t set, oldset;
    
    printf("\n  >>> Entering critical section <<<\n");
    print_mask("  Before");
    
    sigemptyset(&set);
    sigaddset(&set, SIGINT);
    sigprocmask(SIG_BLOCK, &set, &oldset);  // Save current, ensure SIGINT blocked
    
    print_mask("  During");
    printf("  Doing critical work...\n");
    sleep(2);
    
    sigprocmask(SIG_SETMASK, &oldset, NULL);  // Restore original
    print_mask("  After");
    printf("  >>> Exiting critical section <<<\n\n");
}

void caller1() {
    printf("=== CALLER 1: No signals blocked ===\n");
    print_mask("Caller1 state");
    
    critical_section();
    
    print_mask("Caller1 state after");
    printf("State unchanged (no signals blocked)\n\n");
}

void caller2() {
    sigset_t set;
    
    printf("=== CALLER 2: SIGINT already blocked ===\n");
    
    sigemptyset(&set);
    sigaddset(&set, SIGINT);
    sigprocmask(SIG_BLOCK, &set, NULL);
    
    print_mask("Caller2 state");
    
    critical_section();
    
    print_mask("Caller2 state after");
    printf("State unchanged (SIGINT still blocked)\n\n");
}

void caller3() {
    sigset_t set;
    
    printf("=== CALLER 3: SIGTERM blocked ===\n");
    
    sigemptyset(&set);
    sigaddset(&set, SIGTERM);
    sigprocmask(SIG_BLOCK, &set, NULL);
    
    print_mask("Caller3 state");
    
    critical_section();
    
    print_mask("Caller3 state after");
    printf("State unchanged (SIGTERM still blocked, not SIGINT)\n\n");
}

int main() {
    signal(SIGINT, handler);
    signal(SIGTERM, handler);
    
    caller1();  // No signals blocked
    caller2();  // SIGINT already blocked
    caller3();  // Different signal blocked
    
    return 0;
}
