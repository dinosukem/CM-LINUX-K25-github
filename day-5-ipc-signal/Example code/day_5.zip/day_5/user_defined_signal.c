#include <stdio.h>
#include <signal.h>
#include <unistd.h>

int counter = 0;

// Handler for SIGUSR1 - Increment counter
void sigusr1_handler(int signum) {
    counter++;
    printf("\n[SIGUSR1] Counter incremented: %d\n", counter);
    // sleep(3);
}

// Handler for SIGUSR2 - Reset counter
void sigusr2_handler(int signum) {
    printf("\n[SIGUSR2] Counter reset from %d to 0\n", counter);
    counter = 0;
}

int main() {
    // Register signal handlers
    signal(SIGUSR1, sigusr1_handler);
    signal(SIGUSR2, sigusr2_handler);
    
    printf("=== Simple Counter Program ===\n");
    printf("PID: %d\n\n", getpid());
    printf("Commands:\n");
    printf("  Increment: kill -SIGUSR1 %d\n", getpid());
    printf("  Reset:     kill -SIGUSR2 %d\n", getpid());
    printf("  Stop:      kill -SIGINT %d  (or Ctrl+C)\n\n", getpid());
    
    // Main loop
    while (1) {
        printf("Counter: %d (waiting for signals...)\n", counter);
        sleep(3);
    }
    
    return 0;
}
