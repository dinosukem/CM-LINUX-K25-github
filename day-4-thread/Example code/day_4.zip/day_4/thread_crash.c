#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

void* thread1(void* arg) {
    for (int i = 1; i <= 10; i++) {
        printf("Thread 1: Count = %d\n", i);
        sleep(1);
    }
    return NULL;
}

void* thread2(void* arg) {
    for (int i = 1; i <= 10; i++) {
        printf("Thread 2: Count = %d\n", i);
        sleep(1);
        
        if (i == 3) {
            printf("Thread 2: ERROR! Crashing...\n");
            int* ptr = NULL;
            *ptr = 100;  // Segmentation fault
        }
    }
    return NULL;
}

void* thread3(void* arg) {
    for (int i = 1; i <= 10; i++) {
        printf("Thread 3: Count = %d\n", i);
        sleep(1);
    }
    return NULL;
}

int main() {
    pthread_t t1, t2, t3;
    
    printf("=== Starting 3 threads ===\n");
    
    pthread_create(&t1, NULL, thread1, NULL);
    pthread_create(&t2, NULL, thread2, NULL);
    pthread_create(&t3, NULL, thread3, NULL);
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    
    printf("=== All threads completed ===\n");
    return 0;
}
