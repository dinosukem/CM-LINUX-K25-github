#include <stdio.h>
#include <pthread.h>

pthread_spinlock_t spinlock;
int counter = 0;

void* increment(void* arg) {
    for (int i = 0; i < 100000; i++) {
        pthread_spin_lock(&spinlock);     // Spinlock
        counter++;                        // Critical section
        sleep(10);
        pthread_spin_unlock(&spinlock);   // Unlock
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;
    
    pthread_spin_init(&spinlock, PTHREAD_PROCESS_PRIVATE);
    
    pthread_create(&t1, NULL, increment, NULL);
    pthread_create(&t2, NULL, increment, NULL);
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    
    printf("Counter = %d\n", counter);
    
    pthread_spin_destroy(&spinlock);
    return 0;
}
