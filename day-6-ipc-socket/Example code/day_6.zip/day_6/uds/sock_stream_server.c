#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "/tmp/my_socket"
#define BUFFER_SIZE 1024

int main() {
    int server_fd, client_fd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];
    
    // 1. Create Unix Domain Socket (SOCK_STREAM)
    server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket failed");
        return 1;
    }
    printf("[SERVER] Unix domain socket created\n");
    
    // 2. Remove old socket file if exists
    unlink(SOCKET_PATH);
    
    // 3. Setup address (file path)
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);
    
    printf("[SERVER] Socket path: %s\n", server_addr.sun_path);
    
    // 4. Bind to file path
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        close(server_fd);
        return 1;
    }
    printf("[SERVER] Bound to %s\n", SOCKET_PATH);
    
    // 5. Listen
    if (listen(server_fd, 5) < 0) {
        perror("listen failed");
        close(server_fd);
        return 1;
    }
    printf("[SERVER] Listening...\n\n");
    
    // 6. Accept
    printf("[SERVER] Waiting for client...\n");
    client_fd = accept(server_fd, NULL, NULL);
    if (client_fd < 0) {
        perror("accept failed");
        close(server_fd);
        return 1;
    }
    printf("[SERVER] Client connected!\n");
    
    // 7. Receive
    memset(buffer, 0, BUFFER_SIZE);
    int bytes = read(client_fd, buffer, BUFFER_SIZE);
    if (bytes > 0) {
        printf("[SERVER] Received: %s\n", buffer);
    }
    
    // 8. Send
    const char *response = "Hello from Unix socket server!";
    write(client_fd, response, strlen(response));
    printf("[SERVER] Sent: %s\n", response);
    
    // 9. Close
    close(client_fd);
    close(server_fd);
    unlink(SOCKET_PATH);  // Remove socket file
    printf("[SERVER] Closed\n");
    
    return 0;
}


// 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000001