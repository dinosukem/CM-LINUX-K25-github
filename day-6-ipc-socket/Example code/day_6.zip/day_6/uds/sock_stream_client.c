#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "/tmp/my_socket"
#define BUFFER_SIZE 1024

int main() {
    int client_fd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];
    
    // 1. Create Unix Domain Socket (SOCK_STREAM)
    client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (client_fd < 0) {
        perror("socket failed");
        return 1;
    }
    printf("[CLIENT] Unix domain socket created\n");
    
    // 2. Setup server address (file path)
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);
    
    printf("[CLIENT] Connecting to: %s\n", server_addr.sun_path);
    
    // 3. Connect
    if (connect(client_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect failed");
        close(client_fd);
        return 1;
    }
    printf("[CLIENT] Connected!\n");
    
    // 4. Send
    const char *message = "Hello from Unix socket client!";
    write(client_fd, message, strlen(message));
    printf("[CLIENT] Sent: %s\n", message);
    
    // 5. Receive
    memset(buffer, 0, BUFFER_SIZE);
    int bytes = read(client_fd, buffer, BUFFER_SIZE);
    if (bytes > 0) {
        printf("[CLIENT] Received: %s\n", buffer);
    }
    
    // 6. Close
    close(client_fd);
    printf("[CLIENT] Closed\n");
    
    return 0;
}
