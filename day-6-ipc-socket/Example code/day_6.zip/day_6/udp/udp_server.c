#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int server_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];
    
    // 1. socket() - Create UDP socket
    server_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_fd < 0) {
        perror("socket failed");
        return 1;
    }
    printf("[SERVER] UDP socket created\n");
    
    // 2. bind() - Bind to address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    // server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    server_addr.sin_port = htons(PORT); // Host TO Network Short (16-bit, for port numbers)
    
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        close(server_fd);
        return 1;
    }
    printf("[SERVER] Bound to port %d\n", PORT);
    printf("[SERVER] Waiting for messages...\n\n");
    
    // 3. recvfrom() - Receive data (no connection needed!)
    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        
        int bytes = recvfrom(server_fd, buffer, BUFFER_SIZE, 0,
                            (struct sockaddr*)&client_addr, &client_len);
        
        if (bytes > 0) {
            printf("[SERVER] Received from %s:%d\n",
                   inet_ntoa(client_addr.sin_addr),
                   ntohs(client_addr.sin_port));
            printf("[SERVER] Message: %s\n", buffer);
            
            // 4. sendto() - Send response back
            const char *response = "Message received!";
            sendto(server_fd, response, strlen(response), 0,
                   (struct sockaddr*)&client_addr, client_len);
            printf("[SERVER] Response sent\n\n");
        }
    }
    
    // 5. close()
    close(server_fd);
    return 0;
}
