// main.c
#include <stdio.h>
#include "math.h"

#define VERSION "1.0"

int main() {
    printf("Simple Compilation Demo v%s\n", VERSION);
    printf("5 + 3 = %d\n", add(5, 3));
    printf("5 * 3 = %d\n", multiply(5, 3));
    return 0;
}

