// math.c
#include "math.h"

int add(int a, int b) {
    return a + b +1;
}

int multiply(int a, int b) {
    return a * b;
}

