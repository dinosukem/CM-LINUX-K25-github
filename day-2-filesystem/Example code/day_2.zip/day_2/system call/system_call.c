#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

int main() {
    int fd;
    char buffer[100];
    
    printf("Program started\n");
    
    // Create and write to a file
    fd = open("test_file.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd == -1) {
        printf("Error opening file for write: %s\n", strerror(errno));
        return 1;
    }
    printf("File opened for writing, fd = %d\n", fd);
    write(fd, "Hello World!\n", 13);
    // fsync(fd);
    close(fd);
    printf("Program finished\n");
    return 0;
}

