#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd = open("data.txt", O_RDONLY);
    struct flock lock;
    
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_RDLCK;      // Shared/Read lock
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;             // Lock entire file
    
    printf("Reader: Acquiring shared lock...\n");
    if (fcntl(fd, F_SETLKW, &lock) == 0) {
        printf("Reader: Reading file (10 seconds)...\n");
        
        char buffer[100];
        read(fd, buffer, sizeof(buffer));
        printf("Reader: Data: %s\n", buffer);
        
        sleep(10);  // Hold lock while reading
        
        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
        printf("Reader: Lock released\n");
    }
    
    close(fd);
    return 0;
}
