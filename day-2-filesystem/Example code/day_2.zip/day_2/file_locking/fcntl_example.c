#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd = open("data.txt", O_CREAT | O_RDWR, 0644);
    struct flock lock;
    
    // Lock only bytes 10-20
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 10;   // Start at byte 10
    lock.l_len = 10;     // Lock 10 bytes (10-19)
    
    printf("Locking bytes 10-19...\n");
    // F_SETLK: non-blocking
    if (fcntl(fd, F_SETLK, &lock) == 0) {
        printf("Partial lock acquired\n");
        printf("Bytes 10-19 are locked, rest of file is accessible\n");
        sleep(10);
        
        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
        printf("Lock released\n");
    } else {
        printf("Lock is held by another process\n");
    }
    
    close(fd);
    return 0;
}
