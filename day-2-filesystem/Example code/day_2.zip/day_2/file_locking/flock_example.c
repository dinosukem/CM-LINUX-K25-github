#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
#include <errno.h>
#include <string.h>

int main() {
    int fd;
    
    printf("Opening file...\n");
    fd = open("test_lock.txt", O_CREAT | O_RDWR, 0644);
    if (fd == -1) {
        perror("open");
        return 1;
    }
    
    printf("Attempting to acquire exclusive lock with flock()...\n");

    // Lock
    if (flock(fd, LOCK_EX) == -1) {
        perror("flock");
        close(fd);
        return 1;
    }
    
    printf("Lock acquired! Holding for 10 seconds...\n");
    printf("Try running another instance now!\n");
    
    write(fd, "Data written by flock\n", 22);
    sleep(10);
    
    // printf("Releasing lock...\n");
    // flock(fd, LOCK_UN);  // Unlock
    
    // close(fd);
    printf("Done!\n");
    return 0;
}
